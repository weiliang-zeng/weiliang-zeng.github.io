//file: cal_MI_L_bound.cpp
//description: calculate lower bound by mex function 
//author: W. Zeng
//created date: 04-18-2011

#include "mex.h"
#include <complex>
#include <iostream>
#include <string>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

#define Pi 3.1415926f

// creat a 2 dimension array with dimension $rows \times cols$
template <class T>
inline void Make2DArray( T ** &x, int rows, int cols)
{	
  int i;
  x = new T * [rows]; // create a row array of pointers

  //allocate memory for each row
  for (i = 0 ;  i< rows; i++)
    {
      x[i] = new T [cols]; 
    }
}

// free the memory of a 2 dimension array with dimension $rows \times cols$
template <class T>
inline void  Delete2DArray( T ** &x, int rows)
{
  int i; 
  // delete space of each allocated row
  for (i = 0 ; i < rows ; i++) 
    {
      delete [ ] x[i];
    }
  delete [] x; 	//delete the row array of pointers 
  x = 0;
}

// description: return summation of multiplication of two vecters. sum(a(i)*b(i)), i = 1,2...L.  L is the length of vecter a and b
template <class T>
inline T vec_sum_mul(T *vec_a,  T *vec_b, int L)
{
  int i; 
  T tmp = vec_a[0]*vec_b[0];
  for(i = 1; i < L; i++)
    {
      tmp = tmp + vec_a[i]*vec_b[i]; 
    }
  return tmp;
}

//description: C function to calculate mutual information lower bound
double cal_mutual_info_c(complex <double> **chnl_eq, 
			 complex <double>**sym_mod_mat,
			 double noise_power,
			 int Ns, int Nr, int K, int Mc)
{
  int m, k, i;
  int pow_M_NsK, Ns_K, Nr_K;
  double sigma, sigma_tmp, mutual_info; 
  double sum_log_sum_exp, sum_exp_tmp;
  double noise_norm_2_tmp, norm_2_tmp, tmp1;
  double real_tmp, imag_tmp,double_tmp1;
  complex <double> **chnl_eq_sym_mod;  
  complex <double> cmplx_tmp; 
		
  Ns_K = Ns*K;
  Nr_K = Nr*K;
  pow_M_NsK = int(pow(2.0, Ns*K*Mc));
  sigma = sqrt(1.0/2); // standard deviation of noise of I or Q path
    
  //allocate memory
  try
    {
      Make2DArray(chnl_eq_sym_mod, pow_M_NsK, Nr_K); // allocate a matrix of chnl_eq* sym_mod_mat
    }
  catch (exception& e)
    {
      cout << "Standard exception: " << e.what() << endl;
    }

  // chnl_eq/sqrt(noise_power)
  sigma_tmp = sqrt(noise_power); 
  for(m = 0;m < Nr_K; m++) 
    {
      for(k = 0;k < Ns_K; k++)
	{
	  chnl_eq[m][k] = chnl_eq[m][k] / sigma_tmp;
	}
    }
    
  //calculate chnl_eq* sym_mod_mat
  for(m = 0;m < pow_M_NsK; m++) 
    {
      for(k = 0;k < Nr_K; k++)
	{
	  chnl_eq_sym_mod[m][k] = vec_sum_mul(chnl_eq[k],  sym_mod_mat[m], Ns_K);
	}
    }
    
  // calculate sum(log(sum(exp(-|He*(Xm-Xk)|^2/(2*sigma^2)))))
  sum_log_sum_exp = 0;
  for(m = 0; m < pow_M_NsK; m++)
    {
      sum_exp_tmp = 0;
      for(k = 0; k < pow_M_NsK; k++)
	{
	  //calculate ||He*Xm - He*Xk ||^2
	  norm_2_tmp = 0;
	  for(i = 0; i < Nr_K;i++) 
	    {
	      cmplx_tmp = chnl_eq_sym_mod[m][i] - chnl_eq_sym_mod[k][i]; // He*Xm - He*Xk
	      real_tmp = cmplx_tmp.real();
	      imag_tmp = cmplx_tmp.imag();
	      double_tmp1 = real_tmp * real_tmp + imag_tmp * imag_tmp;
	      norm_2_tmp = norm_2_tmp +  double_tmp1; //real_tmp * real_tmp + imag_tmp * imag_tmp;
	      //norm_2_tmp = norm_2_tmp + double_tmp1; //norm(cmplx_tmp);  // ||He*Xm - He*Xk ||^2
	    }
	  tmp1 = - norm_2_tmp/2.0;
	  sum_exp_tmp = sum_exp_tmp + exp(tmp1); //sum(exp(tmp1(k)))
	}
      sum_log_sum_exp = sum_log_sum_exp + log(sum_exp_tmp); //sum(ln(sum(tmp1(k))))
    }

  //mutual information
  mutual_info = Ns*Mc - Nr*(1.0/log(2.0)-1) - (sum_log_sum_exp/pow_M_NsK)/(K*log(2.0)); // K = 1

  //free memory
  Delete2DArray(chnl_eq_sym_mod, pow_M_NsK);  
			
  return mutual_info;
}

//description: mex function of 
// interface between matlab and C program
//mutual_info = cal_mutual_info_matlab(chnl_eq, sym_mod_mat, noise_power, Ns); 
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  int i, j,k;
  int row_num,col_num;
  int Nr_K, Ns_K, pow_M_NsK, K, Nr, Ns, Mc, Mc_Ns_K;
  double *chnl_eq_real, *chnl_eq_imag;
  double *sym_mod_mat_real, *sym_mod_mat_imag;
  double  *noise_power;
  double *Ns_pointer, *sim_num_pointer;
  double *mutual_info;
  complex <double> **chnl_eq_cmplx, **sym_mod_mat_cmplx; 

  //check input and output
  // check number of inputs and output
  if (nrhs  != 4){  
    mexErrMsgTxt("number of inputs errors)");
  }
  if (nlhs  != 1){
    mexErrMsgTxt("number of outputs errors");
  }
  //check inputs and outputs are real or complex
  if ( (!mxIsComplex(prhs[0]))||(!mxIsComplex(prhs[1])) ){
    mexErrMsgTxt("chnl_eq and sym_mod_mat must be complex");
  }
  else if( (mxIsComplex(prhs[2]))||(mxIsComplex(prhs[3]))) {
    mexErrMsgTxt("noise_power and Ns must be real");
  }

  //Retrieve the input data 
  // get chnl_eq
  chnl_eq_real = mxGetPr(prhs[0]);     
  chnl_eq_imag = mxGetPi(prhs[0]);
  Nr_K = int(mxGetM(prhs[0])); // Nr*K
  Ns_K = int(mxGetN(prhs[0]));

  //get sym_mod_mat  
  sym_mod_mat_real = mxGetPr(prhs[1]);     
  sym_mod_mat_imag = mxGetPi(prhs[1]);	
  pow_M_NsK = int(mxGetM(prhs[1])); //M^(Ns*K)
  Mc_Ns_K = int(log(double(pow_M_NsK))/log(2.0)); // bits per symbol of modulation
  Mc = int (Mc_Ns_K/Ns_K);

  //get noise_power
  noise_power = mxGetPr(prhs[2]);
 
  //get Ns
  Ns_pointer = mxGetPr(prhs[3]);
  Ns = int(*Ns_pointer);
  K = int(Ns_K/Ns); 
  Nr = int(Nr_K/K);

  //allocate memory 
  try
    {
      Make2DArray(chnl_eq_cmplx, Nr_K, Ns_K); // allocate a matrix of chnl_eq_cmplx
      Make2DArray(sym_mod_mat_cmplx, pow_M_NsK, Ns_K); 
    }
  catch (exception& e)
    {
      cout << "Standard exception: " << e.what() << endl;
    }

  //convert inputs to be used in c language function
  for(i= 0; i< Ns_K; i++)   // convert chnl_eq to complex class with order in C
    {
      for(k= 0; k< Nr_K; k++)
	{
	  chnl_eq_cmplx[k][i]= complex <double>(chnl_eq_real[i*Nr_K+ k], chnl_eq_imag[i*Nr_K+k]); 
	}	
    }

  for(i= 0; i< Ns_K; i++)   // convert sym_mod_mat to complex class
    {
      for(k= 0; k< pow_M_NsK; k++)
	{
	  sym_mod_mat_cmplx[k][i] = complex <double>(sym_mod_mat_real[i*pow_M_NsK+ k], sym_mod_mat_imag[i*pow_M_NsK+k]);  
	}	
    }

  //Create an mxArray for the output data 
  plhs[0] = mxCreateDoubleMatrix(1,1, mxREAL); 
  mutual_info = mxGetPr(plhs[0]); // Create a pointer to the output data

  // calculate mutual infomation 
  (*mutual_info) = cal_mutual_info_c(chnl_eq_cmplx, sym_mod_mat_cmplx, *noise_power, Ns, Nr, K, Mc); 

  //free memory of allocated arrays
  Delete2DArray( chnl_eq_cmplx, Nr_K);  
  Delete2DArray(sym_mod_mat_cmplx, pow_M_NsK); 
}


