% Create: 04-30-2011
% Author: Weiliang Zeng

% Please run the function ``mexAllFile.m'' first. It will compile the C/C++ 
% codes in the ``func'' directory.

% Reference:
% [1] *W. Zeng*, C. Xiao, and J. Lu, "A Low-Complexity Design of Linear Precoding 
% for MIMO Channels with Finite-Alphabet Inputs," /IEEE Wireless Commun. Letters/, 
% vol. 1, no. 1, pp. 38-41, Feb. 2012.

% Thanks to Dr. Mingxi Wang for discussion on the MEX function of MATLAB

clc;
clear;

analy = 1; % 1: Calculate lower bound
simul = 1; % 1: Calculate simulated mutual information. It takes several minutes for 4x4 case

% Parameter for case 1, 2, 3, 4 for Fig. 1 in Reference [1]
simu_para_table = [
    % corr[1:2] Ch.Nt Ch.Nr Ch.m
    .95 2 2 1
    .95 2 2 2
    .85 3 3 2
    .75 4 4 2
    ];

path(path,'./func');
file_home = pwd;
if ispc == 1
	fileSign = '\';
else
	fileSign = '/';
end;

for simu_idx = 1:length(simu_para_table(:,1))
    Ch.m = simu_para_table(simu_idx,4);% 1 for BPSK; 2 for QPSK
    Ch.M = 2^Ch.m;% 2 for BPSK; 4 for QPSK
    Ch.Nt = simu_para_table(simu_idx,2);% transmit antenna
    Ch.Nr = simu_para_table(simu_idx,3);% receive antenna
    [Ch.sym_mod, Ch.sym_mod_mat] = modConfig(Ch);
    
    SNRdB = -15:2.5:35;
    snr = 10.^(SNRdB./10); %linear value of SNR
    Ch.sim_num = 2000;     %number of noise at each SNR
    
    Ch.H = zeros(Ch.Nr, Ch.Nt);
    % Exponential correlation model.
    for i = 1:Ch.Nr
        for j = 1:Ch.Nt
            Ch.H(i,j) = simu_para_table(simu_idx, 1)^(abs(i-j)); % generate transmitter correlation
        end;
    end;
    
    Ch.H = Ch.H/sqrt(trace(Ch.H*Ch.H'))*sqrt(Ch.Nr); % normalize the channel
    [Ch.H_l Ch.H_d Ch.H_r] = svd(Ch.H);
    
    P = eye(Ch.Nt);
    
    if analy == 1 % bound caculation
        HP = Ch.H * P; %equivalent channel matrix H_eq = H*P
        HP = complex(real(HP),imag(HP)); %convert chnl_eq to complex form of matrix, to be used in C program
        for s = 1:length(SNRdB)
            Ch.noise_power = 1/snr(s); %total power of complex noise.
            MI_L(simu_idx,s) = cal_MI_L_bound_c(HP, Ch.sym_mod_mat, Ch.noise_power, Ch.Nt);
        end;
        plot(SNRdB, MI_L(simu_idx,:)+(1/log(2)-1)*Ch.Nt,'-');hold on;
    end;
    
    if simul == 1 % MI simulations
        HP = Ch.H * P; %equivalent channel matrix H_eq = H*P
        HP = complex(real(HP),imag(HP)); %convert chnl_eq to complex form of matrix, to be used in C program
        for s = 1:length(SNRdB)
            Ch.noise_power = 1/snr(s); %total power of complex noise.
            % mex file to calculate mutual information
            MI_c_ind(s) = cal_MI_c(HP, Ch.sym_mod_mat, Ch.noise_power, Ch.Nt, Ch.sim_num);
        end;
        MI_c(simu_idx,:) = MI_c_ind;
        plot(SNRdB, MI_c(simu_idx,:), 'r*');hold on;
    end;
end;
hold off;