% Create: 09-Aug-2013
% Author: Weiliang Zeng
% Email: zengwe@mst.edu

Please run the function ``mexAllFile.m'' first. It will compile the C/C++ codes in the ``func'' directory.

The file ``Example_Fig1_Zeng2011WCL.m'' is the main function. You may start from that.