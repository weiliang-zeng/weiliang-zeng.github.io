function [phi_t phi_r] = CorrelationGen(Nt, Nr, method, para)

phi_t = zeros(Nt, Nt);
phi_r = zeros(Nr, Nr);

if method == 2    
    % Exponential correlation model.
    for i = 1:Nt
        for j = 1:Nt
            phi_t(i,j) = para(1)^(abs(i-j)); % generate transmitter correlation
        end;
    end;
    for i = 1:Nr
        for j = 1:Nr
            phi_r(i,j) = para(2)^(abs(i-j)); % generate receiver correlation
        end;
    end;
end;