//file: cal_MI_c.cpp
//description: function to calculate MI through Monte Calo simulation
//author: Weiliang
//Updated date: 10-29-2011

#include "mex.h"
#include "matrix.h"
#include <iostream>
#include <complex>
#include <string>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

#define Pi 3.1415926f

// creat a 2 dimension array with dimension rows x cols
template <class T>
inline void Make2DArray( T ** &x, int rows, int cols)
{	
  int i;
  x = new T * [rows]; // create a row array of pointers

  //allocate memory for each row
  for (i = 0 ;  i< rows; i++)
    {
      x[i] = new T [cols]; 
    }
}

// free the memory of a 2 dimension array with dimension rows x cols
template <class T>
inline void  Delete2DArray( T ** &x, int rows)
{
  int i; 
  // delete space of each allocated row
  for (i = 0 ; i < rows ; i++) 
    {
      delete [ ] x[i];
    }
  delete [] x; 	//delete the row array of pointers 
  x = 0;
}

// description: return summation of multiplication of two vecters. sum(a(i)*b(i)), i = 1,2...L.  L is the length of vecter a and b
template <class T>
inline T vec_sum_mul(T *vec_a,  T *vec_b, int L)
{
  int i; 
  T tmp = vec_a[0]*vec_b[0];
  for(i = 1; i < L; i++)
    {
      tmp = tmp + vec_a[i]*vec_b[i]; 
    }
  return tmp;
}


//description: generate a complex gaussian random number, mean is zero, total variance is 2
//method: Box-Muller transform
inline complex <double> cmplx_gauss()
{
  double randn_real, randn_imag;
  double u1, u2;
  u1 = ((float)rand()) / RAND_MAX; // random number between (0,1]
  u2 = ((float)rand()) / RAND_MAX;
  while (u1==0){
      u1 = ((float)rand()) / RAND_MAX;
  }
  randn_real =  (sqrt(-2.0*log(u1)) * cos(2*Pi*u2)); //randn_real ~ N(0, 1)
  randn_imag = (sqrt(-2.0*log(u1)) * sin(2*Pi*u2)); //randn_imag ~ N(0, 1)
//   if (mxIsNaN(randn_real)){
//       cout<<"Nan occours at a."<<endl;
//   };
//   if (mxIsNaN(randn_imag)){
//       cout<<"Nan occours at b."<<endl;
//   };
  return complex <double> (randn_real, randn_imag);
}

//description: generate a complex gaussian random vector of length L. Each element is independent ~CN(0, 2*(sigma^2))
inline void cmplx_gauss_vec(complex <double> *gauss_vec, double sigma, int L)
{
  int i;
  for(i = 0; i < L; i++)
    {
      gauss_vec[i] = sigma * cmplx_gauss();
//       cout<<"Output:"<<gauss_vec[i].real()<<gauss_vec[i].imag()<<endl;
    }
}


//description: C function to calculate mutual information through Monte Calo simulation
double cal_mutual_info_c(complex <double> **chnl_eq, 
			 complex <double>**sym_mod_mat,
			 double noise_power,
			 int sim_num,
			 int Ns, int Nr, int K, int Mc)
{
  int m, k, i;
  int pow_M_NsK, Ns_K, Nr_K;
  int sim_cnt;
  double sigma, sigma_tmp, mutual_info; 
  double avg_sum_log_sum_exp, sum_log_sum_exp, sum_exp_tmp;
  double avg_noise_norm_2, noise_norm_2_tmp, norm_2_tmp, tmp1;
  double real_tmp, imag_tmp,double_tmp1;
  complex <double> *noise_vec; 
  complex <double> **chnl_eq_sym_mod;  
  complex <double> cmplx_tmp; 
		
  Ns_K = Ns*K;
  Nr_K = Nr*K;
  pow_M_NsK = int(pow(2.0, Ns*K*Mc));
  sigma = sqrt(1.0/2); // standard deviation of noise of I or Q path
    
  //allocate memory
  try
    {
      noise_vec = new complex <double> [Nr_K]; //allocate memory for noise vector  
      Make2DArray(chnl_eq_sym_mod, pow_M_NsK, Nr_K); // allocate a matrix of chnl_eq* sym_mod_mat
    }
  catch (exception& e)
    {
      cout << "Standard exception: " << e.what() << endl;
    }

  // chnl_eq/sqrt(noise_power)
  sigma_tmp = sqrt(noise_power); 
  for(m = 0;m < Nr_K; m++) 
    {
      for(k = 0;k < Ns_K; k++)
	{
	  chnl_eq[m][k] = chnl_eq[m][k] / sigma_tmp;
	}
    }
    
  //calculate chnl_eq* sym_mod_mat
  for(m = 0;m < pow_M_NsK; m++) 
    {
      for(k = 0;k < Nr_K; k++)
	{
	  chnl_eq_sym_mod[m][k] = vec_sum_mul(chnl_eq[k],  sym_mod_mat[m], Ns_K);
	}
    }
    
  // simulate Expection of sum(log(sum(exp(-|He*(Xm-Xk) + V|^2)))) over noise vector V
  avg_sum_log_sum_exp = 0;
  avg_noise_norm_2 = 0; 
  for(sim_cnt = 0; sim_cnt < sim_num; sim_cnt++)
    {
      // generate vector of complex guassian noise 
      cmplx_gauss_vec(noise_vec, sigma, Nr_K);         

      //calculate ||V||^2
      noise_norm_2_tmp = 0;
      for (i = 0; i < Nr_K; i++)
      {
          if (mxIsNaN(norm(noise_vec[i]))){
              mexErrMsgTxt("NaN occours 1.");
          };
          noise_norm_2_tmp = noise_norm_2_tmp + norm(noise_vec[i]);
      }
      avg_noise_norm_2 = avg_noise_norm_2 + noise_norm_2_tmp;
      
      // calculate sum(log(sum(exp(-|He*(Xm-Xk) + V|^2))))
      sum_log_sum_exp = 0;
      for(m = 0; m < pow_M_NsK; m++)
	{
	  sum_exp_tmp = 0;
	  for(k = 0; k < pow_M_NsK; k++)
	    {
	      //calculate ||He*Xm - He*Xk + V||^2
	      norm_2_tmp = 0;
	      for(i = 0; i < Nr_K;i++) 
		{
		  cmplx_tmp = chnl_eq_sym_mod[m][i] - chnl_eq_sym_mod[k][i] + noise_vec[i]; // He*Xm - He*Xk + V
		  real_tmp = cmplx_tmp.real();
		  imag_tmp = cmplx_tmp.imag();
		  double_tmp1 = real_tmp * real_tmp + imag_tmp * imag_tmp;
		  norm_2_tmp = norm_2_tmp +  double_tmp1; //real_tmp * real_tmp + imag_tmp * imag_tmp;
		  //norm_2_tmp = norm_2_tmp + double_tmp1; //norm(cmplx_tmp);  // ||He*Xm - He*Xk + V||^2
		}
	      //tmp1 = - norm_2_tmp/noise_power; //||He*Xm - He*Xk + V||^2/noise_power
	      tmp1 = - norm_2_tmp;
	      sum_exp_tmp = sum_exp_tmp + exp(tmp1); //sum(exp(tmp1(k)))
	    }
	  sum_log_sum_exp = sum_log_sum_exp + log(sum_exp_tmp); //sum(ln(sum(tmp1(k))))
	}
      avg_sum_log_sum_exp = avg_sum_log_sum_exp + sum_log_sum_exp;  
    }
  avg_sum_log_sum_exp = avg_sum_log_sum_exp/sim_num; // average value of sum(ln(sum(tmp1(k))))
  avg_noise_norm_2 = avg_noise_norm_2 / sim_num; //average value of ||V||^2

  //mutual information
  //mutual_info = Ns*Mc - (avg_noise_norm_2/noise_power + avg_sum_log_sum_exp/pow_M_NsK)/(K*log(2.0)); 
  mutual_info = Ns*Mc - (avg_noise_norm_2 + avg_sum_log_sum_exp/pow_M_NsK)/(K*log(2.0)); 

  if (mxIsNaN(avg_sum_log_sum_exp)){
      cout<<"Nan occours 2."<<endl;
  };
  if (mxIsNaN(mutual_info)){
      cout<<"Nan occours 3."<<endl;
  };

  //free memory
  delete [] noise_vec;
  Delete2DArray(chnl_eq_sym_mod, pow_M_NsK);  
			
  return mutual_info;
}


//description: mex function of 
// interface between matlab and C program
//mutual_info = cal_mutual_info_matlab(chnl_eq, sym_mod_mat, noise_power, Ns, sim_num); 
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  int i, j,k;
  int row_num,col_num;
  int Nr_K, Ns_K, pow_M_NsK, K, Nr, Ns, Mc, Mc_Ns_K;
  int sim_num;
  double *chnl_eq_real, *chnl_eq_imag;
  double *sym_mod_mat_real, *sym_mod_mat_imag;
  double  *noise_power;
  double *Ns_pointer, *sim_num_pointer;
  double *mutual_info;
  complex <double> **chnl_eq_cmplx, **sym_mod_mat_cmplx; 

  //check input and output
  // check number of inputs and output
  if (nrhs  != 5){  
    mexErrMsgTxt("number of inputs errors)");
  }
  if (nlhs  != 1){
    mexErrMsgTxt("number of outputs errors");
  }
  //check inputs and outputs are real or complex
  if ( (!mxIsComplex(prhs[0]))||(!mxIsComplex(prhs[1])) ){
    mexErrMsgTxt("chnl_eq and sym_mod_mat must be complex");
  }
  else if( (mxIsComplex(prhs[2]))||(mxIsComplex(prhs[3]))||(mxIsComplex(prhs[4]))) {
    mexErrMsgTxt("noise_power,Ns,and sim_num must be real");
  }

  //Retrieve the input data 
  // get chnl_eq
  chnl_eq_real = mxGetPr(prhs[0]);     
  chnl_eq_imag = mxGetPi(prhs[0]);
  Nr_K = int(mxGetM(prhs[0])); // Nr*K
  Ns_K = int(mxGetN(prhs[0]));

  //get sym_mod_mat  
  sym_mod_mat_real = mxGetPr(prhs[1]);     
  sym_mod_mat_imag = mxGetPi(prhs[1]);	
  pow_M_NsK = int(mxGetM(prhs[1])); //M^(Ns*K)
  Mc_Ns_K = int(log(double(pow_M_NsK))/log(2.0)); // bits per symbol of modulation
  Mc = int (Mc_Ns_K/Ns_K);

  //get noise_power
  noise_power = mxGetPr(prhs[2]);
 
  //get Ns
  Ns_pointer = mxGetPr(prhs[3]);
  Ns = int(*Ns_pointer);
  K = int(Ns_K/Ns); 
  Nr = int(Nr_K/K);

  //get sim_num
  sim_num_pointer = mxGetPr(prhs[4]);
  sim_num = int(*sim_num_pointer);

  //allocate memory 
  try
    {
      Make2DArray(chnl_eq_cmplx, Nr_K, Ns_K); // allocate a matrix of chnl_eq_cmplx
      Make2DArray(sym_mod_mat_cmplx, pow_M_NsK, Ns_K); 
    }
  catch (exception& e)
    {
      cout << "Standard exception: " << e.what() << endl;
    }

  //convert inputs to be used in c language function
  for(i= 0; i< Ns_K; i++)   // convert chnl_eq to complex class with order in C
    {
      for(k= 0; k< Nr_K; k++)
	{
	  chnl_eq_cmplx[k][i]= complex <double>(chnl_eq_real[i*Nr_K+ k], chnl_eq_imag[i*Nr_K+k]); 
	}	
    }

  for(i= 0; i< Ns_K; i++)   // convert sym_mod_mat to complex class
    {
      for(k= 0; k< pow_M_NsK; k++)
	{
	  sym_mod_mat_cmplx[k][i] = complex <double>(sym_mod_mat_real[i*pow_M_NsK+ k], sym_mod_mat_imag[i*pow_M_NsK+k]);  
	}	
    }

  //Create an mxArray for the output data 
  plhs[0] = mxCreateDoubleMatrix(1,1, mxREAL); 
  mutual_info = mxGetPr(plhs[0]); // Create a pointer to the output data

  // calculate mutual infomation 
  (*mutual_info) = cal_mutual_info_c(chnl_eq_cmplx, sym_mod_mat_cmplx, *noise_power,sim_num, Ns, Nr, K, Mc); 

  //free memory of allocated arrays
  Delete2DArray( chnl_eq_cmplx, Nr_K);  
  Delete2DArray(sym_mod_mat_cmplx, pow_M_NsK); 
}


