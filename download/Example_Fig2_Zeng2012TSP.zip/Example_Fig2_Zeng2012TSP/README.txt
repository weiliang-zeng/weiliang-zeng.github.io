% Create: 11-Sep-2013
% Author: Weiliang Zeng
% Email: zengwe@mst.edu

Please run the function ``mexAllFile.m'' first. It will compile the C/C++ codes in the ``func'' directory.

The file ``Example_Fig2_Zeng2012TSP.m'' is the main function. You may start from that.