% Update: 12-04-2011
% Author: Weiliang Zeng

% Please run the function ``mexAllFile.m'' first. It will compile the C/C++
% codes in the ``func'' directory.

% Reference:
% [1] *W. Zeng*, C. Xiao, M. Wang, and J. Lu, "Linear Precoding for Finite-Alphabet
% Inputs Over MIMO Fading Channels With Statistical CSI," /IEEE Trans. Signal Process./,
% vol. 60, no. 6, pp. 3134-3148, Jun. 2012.

% Thanks to Dr. Mingxi Wang for discussion on the MEX function of MATLAB

clc;
clear;

analy = 1; % 1: Calculate lower bound
simul = 1; % 1: Calculate simulated mutual information. It may take several minutes for 3x3 and 4x4 case

% Parameter for different cases in Reference [1]
simu_para_table = [
    % corr[1:2] Ch.Nt Ch.Nr Ch.m
    .8 .8 2 2 1
    .8 .8 2 2 2
%     .5 .5 3 3 2
%     .2 .2 4 4 2
    ];% simulation parameter

SNRdB = -20:2:20;

path(path,'./func');
file_home = pwd;
if ispc == 1
	fileSign = '\';
else
	fileSign = '/';
end;

for simu_idx = 1:length(simu_para_table(:,1))
    Ch.m = simu_para_table(simu_idx,5);% 1 for BPSK; 2 for QPSK
    Ch.M = 2^Ch.m;% 2 for BPSK; 4 for QPSK
    Ch.Nt = simu_para_table(simu_idx,3);% transmit antenna
    Ch.Nr = simu_para_table(simu_idx,4);% receive antenna
    [Ch.sym_mod, Ch.sym_mod_mat] = modConfig(Ch);

    snr = 10.^(SNRdB./10); %linear value of SNR
    Ch.sim_num = 2000;     %number of noise at each SNR
    Ch.Hw_num = 1000;

    [Ch.phi_t Ch.phi_r] = CorrelationGen(Ch.Nt, Ch.Nr, 2, simu_para_table(simu_idx,[1:2]));
    [Ch.phi_t_U, Ch.phi_t_D] = eig(Ch.phi_t);
    Ch.phi_t_2 = Ch.phi_t_U * sqrt(Ch.phi_t_D) * (Ch.phi_t_U)';
    [Ch.phi_r_U, Ch.phi_r_D] = eig(Ch.phi_r);
    Ch.phi_r_2 = Ch.phi_r_U * sqrt(Ch.phi_r_D) * (Ch.phi_r_U)';

    if analy == 1 % bound caculation
        for s = 1:length(SNRdB)
            Ch.noise_power = 1/snr(s); %total power of complex noise.
            P = eye(Ch.Nt);
            HP = sqrt(Ch.phi_t_D)*Ch.phi_t_U'*P;
            HP = complex(real(HP),imag(HP));
            r = diag(Ch.phi_r_D);
            AMI_L(simu_idx,s) = cal_AMI_L_bound_c(HP, Ch.sym_mod_mat, Ch.noise_power, Ch.Nt, r');
        end;
        plot(SNRdB, AMI_L(simu_idx,:)+(1/log(2)-1)*Ch.Nr,'-');hold on;
    end;

    if simul == 1 % AMI simulations
        randn('state', 0);
        for i = 1:Ch.Hw_num
            Ch.Hw = comprandn(Ch.Nr, Ch.Nt, 1);
            Ch.H = Ch.phi_r_2 * Ch.Hw * Ch.phi_t_2;
            P = eye(Ch.Nt);
            HP = Ch.H * P; %equivalent channel matrix H_eq = H*P
            HP = complex(real(HP),imag(HP)); %convert chnl_eq to complex form of matrix, to be used in C program
            if mod(i, 100)==0
                fprintf('Case = %d; ChannelNum = %d / %d\n', simu_idx, i, Ch.Hw_num);
            end;
            for s = 1:length(SNRdB)
                Ch.noise_power = 1/snr(s); %total power of complex noise.
                                           % mex file to calculate mutual information
                MI_c(i, s) = cal_MI_c(HP, Ch.sym_mod_mat, Ch.noise_power, Ch.Nt, Ch.sim_num);
            end;
        end;
        AMI_c(simu_idx,:) = mean(MI_c, 1);
        plot(SNRdB, AMI_c(simu_idx,:), 'r*');hold on;
    end;
end;
hold off;