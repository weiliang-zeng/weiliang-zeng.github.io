% mex_all Creates MEX files for all files in directory
% Requires a C compiler
% Type help mex for more information on creating mex files
%
% This program need be run only once

function mexAllFile

currentdir=cd;
cd('func');

files=[dir('*.cpp'); dir('*.c')];
for i=1:length(files)
    if strcmp(mexext,'mexw32')||strcmp(mexext,'mexglx')||strcmp(mexext,'mexmac') ||strcmp(mexext,'mexmaci')
        mex(files(i).name)
        disp(['mex file created for ' files(i).name])
    elseif strcmp(mexext,'mexw64')||strcmp(mexext,'mexa64')||strcmp(mexext,'mexmaci64')
        eval(horzcat('mex -largeArrayDims ', files(i).name));
        disp(['mex file created for ' files(i).name])
    end
end
cd(currentdir);